print("Starting import checks...")
try:
    import flask
    print("Flask imported.")
except ImportError as e:
    print(f"FAILED: flask - {e}")

try:
    import neo4j
    print("neo4j imported.")
except ImportError as e:
    print(f"FAILED: neo4j - {e}")

try:
    import dotenv
    print("dotenv imported.")
except ImportError as e:
    print(f"FAILED: dotenv - {e}")

try:
    import requests
    print("requests imported.")
except ImportError as e:
    print(f"FAILED: requests - {e}")

print("Import checks done.")
