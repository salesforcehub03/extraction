print("Testing Flask import...")
try:
    from flask import Flask
    print("from flask import Flask SUCCESS")
except ImportError as e:
    print(f"FAILED: from flask import Flask - {e}")
except Exception as e:
    print(f"ERROR: {e}")

try:
    import werkzeug
    print(f"Werkzeug version: {werkzeug.__version__}")
except ImportError as e:
    print(f"FAILED: import werkzeug - {e}")
